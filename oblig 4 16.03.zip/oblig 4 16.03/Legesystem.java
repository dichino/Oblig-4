import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Legesystem {


    public void settInnFil(){
        Scanner fil = null;
        String filnavn = "legedata.txt";

        try {
            fil = new Scanner(new File(filnavn));
        } catch (FileNotFoundException e) {
            System.out.println("Fil ikke funnet: "+ filnavn);
            System.exit(-1);
        }

        String pasienterListe[];
        String legeListe[];
        String legemidlerListe[];
        String resepterListe[];

        while (fil.hasNextLine()){
            String linje = fil.nextLine();

            String pekerLinje[] = linje.split(" "); 
            if (pekerLinje[0].equals("#")){ //finner # / overskrift
                while (fil.hasNextLine()){
                    String linje2 = fil.nextLine();
        
                    String pekerLinje2[] = linje.split(" "); 
                    while((pekerLinje[0].equals("#")) != true) { //Kjører helt til ny overskrift
                        String biter[] = linje.split(",");
                    }

            }

            

        }
    }
}

 }