class Koe<E> extends Lenkeliste<E>{
    
}