class Spesialister extends Lege implements Godkjenningsfritak  {
    protected String kontrollKode;
  


    public Spesialister(String Legenavn, String kontrollKode){
        super(Legenavn);
        this.kontrollKode = kontrollKode;
    }

    @Override
    public String hentKontrollkode(){
        return kontrollKode;
    }

    @Override
    public String toString(){
        return "navn " + Legenavn + ", kontroll kode: " + kontrollKode;
    }
}
