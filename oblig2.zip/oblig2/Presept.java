class Presept extends hvitResept {
    private static int rabatt=108;

    public Presept(Legemiddel legemiddel, Lege utskrivendeLege, int pasientId, int reit){
        super(legemiddel, utskrivendeLege, pasientId, reit);
    }

    @Override
    public String farge(){
        return "Hvit resept";
    }
    
    @Override
    public int prisAaBetale(){                        //sjekker at pris aldri blir mindre 0
        if (legemiddel.hentPris()- rabatt <= 0){
            return legemiddel.hentPris();
        } else{
            return legemiddel.hentPris() - rabatt;
        }
    }

    @Override
    public String toString(){
        return "Legemiddel --> " + legemiddel + "Lege --> " + utskrivendeLege + ", pasientid: " + pasientId + ", reit: " + reit;
    }
}
