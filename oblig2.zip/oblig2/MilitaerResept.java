 class MilitaerResept extends hvitResept{
    
    public MilitaerResept(Legemiddel legemiddel, Lege utskrivendeLege, int pasientId, int reit){
        super(legemiddel, utskrivendeLege, pasientId, 3);
    }

    @Override
    public String farge(){
        return "Hvit resept";
    }
    
    @Override
    public int prisAaBetale(){
        return 0;
    }
    
    @Override
    public String  toString(){
        return "Legemiddel --> " + legemiddel + "Lege --> " + utskrivendeLege + ", pasientid: " + pasientId + ", reit: " + reit;
    }
}
