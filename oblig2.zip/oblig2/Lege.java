class Lege {
    protected String Legenavn;

    public Lege(String Legenavn){
        this.Legenavn = Legenavn;
    }
    public String hentNavn(){
        return Legenavn;
    }

    
    @Override
    public String toString(){
        return "navn: " + Legenavn;
    }
}
