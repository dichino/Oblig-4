interface Godkjenningsfritak {
    String hentKontrollkode();
    
}
