

//del C
public class Pasient implements Comparable<Pasient> {
    String navn;
    String fodselsnummer;
    private static int teller = 0;
    int pasientId;
    IndeksertListe <Resept> reseptListe = new IndeksertListe<>();  
    
    public Pasient(String navn, String fodselsnummer){
        this.navn = navn;
        this.fodselsnummer = fodselsnummer;
        pasientId = teller;
        teller++;
    }
    
    @Override   //huske å fikse den her
    public String toString(){
        return navn + "(fnr "+fodselsnummer+")";
    }
  
    //E6 hjelpemetode
    public int hentAntNarkotiskeResepter(){
        int ant = 0;
        for (Resept r: reseptListe){
            if(r.hentLegemiddel().hentType().equals("narkotisk")){
                ant++;
            }
        }
        return ant;

    }
//del E6, hjelpemetode
    @Override
    public int compareTo(Pasient annen){
        int pasient = navn.compareTo(annen.navn);
        return pasient;
    }

}
