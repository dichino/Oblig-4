class VanligLegemiddel extends Legemiddel {

    public VanligLegemiddel(String navn, int pris, double virkestoff){
        super(navn, pris, virkestoff);
    }
    
    @Override
    public String toString(){
        return "navn: " + navn + ", pris: " + pris + ", virkestoff: " + virkestoff +"\n";
    }
    //E6
    @Override
    public String hentType(){
        return "vanlig";
    }

    //E7 hjelpemetode
    @Override
    public int hentStyrke(){
        return 0;
    }
}