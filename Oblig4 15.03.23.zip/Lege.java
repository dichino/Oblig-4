class Lege implements Comparable<Lege> {
    protected String Legenavn;

    public Lege(String Legenavn){
        this.Legenavn = Legenavn;
    }
    public String hentNavn(){
        return Legenavn;
    }

//D2
    IndeksertListe<Resept> utskrevneResepter = new IndeksertListe<Resept>();

    public IndeksertListe<Resept> hentListe(){
        return utskrevneResepter;
    }

//D3
    public HvitResept skrivHvitResept (Legemiddel legemiddel, Pasient pasient, int reit) throws UlovligUtskrift {

            HvitResept hvitresept =  new HvitResept();
            

            utskrevneResepter.leggTil(hvitresept);
            
            return hvitresept;
            
    }

    public MilitaerResept skrivMilResept (Legemiddel legemiddel, Pasient pasient) throws UlovligUtskrift{
        Lege lege = new Lege(Legenavn);
        MilitaerResept militaerResept = new MilitaerResept(legemiddel, lege, pasient, 0);
        utskrevneResepter.leggTil(militaerResept);
        return militaerResept;

    }
    
    public PResept skrivPResept (Legemiddel legemiddel, Pasient pasient, int reit) throws UlovligUtskrift{
        return null;

    }

    public BlaaResept skrivBlaaResept (Legemiddel legemiddel, Pasient pasient, int reit) throws UlovligUtskrift{
        return null;

    }



    

    @Override
    public int compareTo(Lege annen){
        int legen = Legenavn.compareTo(annen.Legenavn);
        return legen;
    }

    @Override
    public String toString(){
        return "navn: " + Legenavn;
    }
}
